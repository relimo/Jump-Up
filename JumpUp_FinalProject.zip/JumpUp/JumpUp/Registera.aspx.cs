﻿using JumpUp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JumpUp
{
    public partial class Registera : System.Web.UI.Page
    {
        Bl b = new Bl();
        protected void Page_Load(object sender, EventArgs e)
        {

            err.Visible = false;
            int day = 0;
            for (int i = 0; i < 31; i++)
            {
                day++;
                DropDownList1.Items.Add(day.ToString());
            }
            int month = 0;
            for (int i = 0; i < 12; i++)
            {
                month++;
                DropDownList2.Items.Add(month.ToString());
            }
            int year = 1940;
            for (int i = 0; i < 70; i++)
            {
                year++;
                DropDownList3.Items.Add(year.ToString());
            }
            DropDownList3.Text = "1990";
        }



        protected String hash_password(string password)
        {

            int[] pw = new int[password.Length];
            char[] paw = new char[password.Length];
            int index = 0;
            char temp;
            foreach (char c in password)
            {
                pw[index] = c + index;
                index++;
            }
            index = 0;

            foreach (int p in pw)
            {
                paw[index]=Convert.ToChar(pw[index]);
                index++;
            }
            string s="";
            index = 0;

            foreach (char p in paw)
            {
                s += p;
            }
              


            return s;
        }

       


        //protected String dehash_password(string password)
        //{
        //    int[] pass = new int[8];
        //    int index = 0;
        //    foreach (char c in password)
        //    {
        //        pass[index] = c + 3;
        //        index++;
        //    }
        //    return " ";

        //}



        protected void CreateUserButton_Click(object sender, EventArgs e)
        {
            err.Visible = false;
           
            if (Password.Text.Length > 8 || Password.Text.Length < 6)
            {
                PasswordConstaintsLabel.Visible = true;
                Password.Text = "";
                // Password.
            }
            else CreateUser();
        }

        protected void CreateUser()
        {
            string date = Request.Form[DropDownList1.UniqueID] + "/" + Request.Form[DropDownList2.UniqueID] + "/" + Request.Form[DropDownList3.UniqueID];

            string hashed_pass=hash_password(Password.Text);
            




            string result = b.addClient(UserName.Text, hashed_pass, TextBox1.Text, TextBox2.Text, Email.Text, date);
            if (result.Equals("error"))
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('There ia an error with opening the DB');</script>");
            // Label5.Text="There ia an error with opening the DB";
            else if (result.Equals("false"))
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('There is already such a user name, choose a new one');</script>");
                //err.Visible = true;
                //err.Text = "There is already such a user name, choose a new one!";
            }
            else
            {
                // Label5.Text = "The registration was succeeded! "; 
                Session.Add("userName", UserName.Text);
                Response.Redirect("individual.aspx");

            }
        }

        protected void UserName_TextChanged(object sender, EventArgs e)
        {
            err.Visible = false;
        }
    }
}