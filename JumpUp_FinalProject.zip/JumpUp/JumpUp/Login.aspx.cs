﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;

namespace JumpUp
{
   
    public partial class Login : System.Web.UI.Page
    {
        const int client = 0;
        const int worker = 1;
        const int nor = -1;

        private int status = 0;

        Bl b = new Bl();
        dal d = new dal();

        //protected void Page_Load(object sender, EventArgs e)
        //{
        //    Label2.Visible = false;
            
        //}
        protected String dehash_password(string password)
        {

            int[] pw = new int[password.Length];
            char[] paw = new char[password.Length];
            int index = 0;
            char temp;
            foreach (char c in password)
            {
                pw[index] = c + index;
                index++;
            }
            index = 0;

            foreach (int p in pw)
            {
                paw[index] = Convert.ToChar(pw[index]);
                index++;
            }
            string s = "";
            index = 0;

            foreach (char p in paw)
            {
                s += p;
            }



            return s;
        }
        protected void loginButton_Click(object sender, EventArgs e)
        {

            string deHashedPass = dehash_password(Password.Text);
            int result = b.checkPassword(UserName.Text, deHashedPass);
            if (result==nor)//אין תיאום 
            {
                err.Visible = true;
                err.Text = "either the user name or the password (or both of them..) is not correct";
            }
            else if(result == worker)
            {
                status = worker;
                Session.Add("userName", UserName.Text);
                Session.Add("password", Password.Text);
                Session.Add("role", "Worker");
                Response.Redirect("Worker.aspx");
            }
            //client status
            else
            {
                status = client;
                Session.Add("userName", UserName.Text);
                Session.Add("password", Password.Text);
                Session.Add("role", "Client");
                // TODO: //welcome user name
                //Response.Redirect("YourSite.aspx");
                //    string s = ((Button)Master.FindControl("Button1")).Text;
                //   this.Master.ButtonText = "logOut";
                // ((Button)Master.FindControl("Button1")).Text = "logOut";
                Response.Redirect("individual.aspx");

            }
        }
        
        //restoring password
        protected void Button1_Click(object sender, EventArgs e)
        {
            Label2.Visible = false;
            
            if(UserName.Text == "" )
            {
                Label2.Visible = true;
                Label2.Text = "Please enter your name";
                return;
                
            }
            if (d.UserName_exists(UserName.Text) == "")
            {
                Label2.Visible = true;
                Label2.Text = "User name does not exist";
                return;
            }

            if (d.UserName_exists(UserName.Text) != "")
            {

                //if (String.IsNullOrEmpty(email))
                //    return;
                //try
                //{
                //    MailMessage mail = new MailMessage();
                //    //mail.To.Add(email);
                //    mail.To.Add("chavalevi@gmail.com");
                //    mail.From = new MailAddress("justJumpApp@gmail.com");
                //    mail.Subject = "restore password";

                //    mail.Body = "hi";

                //    mail.IsBodyHtml = true;
                //    SmtpClient smtp = new SmtpClient();
                //    smtp.Host = "smtp.gmail.com"; //Or Your SMTP Server Address
                //    smtp.Credentials = new System.Net.NetworkCredential
                //         ("justJumpApp@gmail.com", "pw"); // ***use valid credentials***
                //    smtp.Port = 587;

                //    //Or your Smtp Email ID and Password
                //    smtp.EnableSsl = true;
                //    smtp.Send(mail);
                //}
                //catch (Exception ex)
                //{
                //    Label2.Visible = true;
                //    Label2.Text = "Exception in sendEmail:" + ex.Message;
                //}
                
                //SmtpClient smtpClient = new SmtpClient("mail.MyWebsiteDomainName.com", 25);

                //smtpClient.Credentials = new System.Net.NetworkCredential("info@MyWebsiteDomainName.com", "myIDPassword");
                //smtpClient.UseDefaultCredentials = true;
                //smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                //smtpClient.EnableSsl = true;
                //MailMessage mail = new MailMessage();

                ////Setting From , To and CC
                //mail.From = new MailAddress("justJumpApp@gmail.com", "MyWeb Site");
                //mail.To.Add(new MailAddress("chavalevi@gmail.com"));
                //mail.CC.Add(new MailAddress("chavalopianski@hotmail.com"));

                //smtpClient.Send(mail);


                try
                {
                    var fromAddress = new MailAddress("justJumpApp@gmail.com", "Jump App");
                    string mail = d.getEmail(UserName.Text);
                    var toAddress = new MailAddress(mail);
                    const string fromPassword = "jump1234";
                    const string subject = "Password Recovery for JumpApp";
                    string msg = "Hi " + d.get_client_name_according_to_user_name(UserName.Text) + ",\nyour password is " + d.getPassword(UserName.Text);
                    string body = msg;

                    var smtp = new SmtpClient
                    {
                        Host = "smtp.gmail.com",
                        Port = 587,
                        EnableSsl = true,
                        DeliveryMethod = SmtpDeliveryMethod.Network,
                        UseDefaultCredentials = false,
                        Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
                    };

                    using (var message = new MailMessage(fromAddress, toAddress)
                    {
                        Subject = subject,
                        Body = body
                    })
                    {
                        smtp.Send(message);
                    }
                    Label2.Visible = true;
                    Label2.Text = "Your password had been sent to your email";
                }
                catch (Exception ex)
                {
                    Label2.Visible = true;
                    Label2.Text = "Error occurred while sending the email";
                }
            }
            //else
            //{
            //    Label2.Visible = true;
            //    Label2.Text = "User name does not exist";
            //}
        }

        protected void UserName_TextChanged(object sender, EventArgs e)
        {
            Button1.Visible = true;
        }

        protected void Password_TextChanged(object sender, EventArgs e)
        {

        }
    }
}