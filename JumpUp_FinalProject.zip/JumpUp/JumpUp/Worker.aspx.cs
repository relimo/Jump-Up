﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace JumpUp
{
    public partial class Worker : System.Web.UI.Page
    {

        dal da = new dal();
        Bl b = new Bl();

        protected void Page_Load(object sender, EventArgs e)
        {
            lessonsList.Visible = false;
            //u1.Visible = false;
            //u2.Visible = false;
            //Label2.Text = da.get_client_name_according_to_user_name((string)Session["userName"]);

            //if (!IsPostBack)
            //{

            //    GridView1.DataSource = da.getDetailsForUser((string)Session["userName"]);

            //    GridView1.DataBind();
            //}
        }
        protected void GridView2_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //string autid = GridView1.DataKeys[e.RowIndex].Value.ToString();
            if (this.GridView2.Rows.Count > 0)
            {
                GridViewRow row = (GridViewRow)GridView2.Rows[e.RowIndex];


                string dt1 = GridView2.Rows[e.RowIndex].Cells[2].Text;
                int room = Convert.ToInt16(GridView2.Rows[e.RowIndex].Cells[3].Text);


                string user = (string)Session["userName"];
                da.delete_lesson(user, dt1, room);
                GridView2.DataSource = da.getDetailsForUser(user);
                GridView2.DataBind();

            }
        }
        protected void cancelLesson_Click(object sender, EventArgs e)
        {
            if(cancelLesson.Text== "Cancel a Lesson from List")
            {
                c_userName.Visible = false;
                lessonsList.Visible = true;
                cancelLesson.Text = "Remove this lesson";
                cancelLesson.Visible = false;
                approveContract.Text = "Back";
                updateData.Visible = false;
                removeTeacher.Visible = false;

                if ((string)Session["userName"] == null)
                    Response.Redirect("Home.aspx");


                string[] arr = b.getAllLessons();
                string[] arrDates = b.getAllDates();
                HtmlGenericControl li;
                HtmlGenericControl anchor;
                for (int i = 0; i < arr.Length - 1; i++)
                {
                    li = new HtmlGenericControl("li");
                    u1.Controls.Add(li);
                    // li.InnerText = "aaa" + i;
                    anchor = new HtmlGenericControl("a");
                    anchor.Attributes.Add("href","Add.aspx?name=" + arr[i] + "&name_or_date=n");
                    anchor.InnerText = arr[i];
                    li.Controls.Add(anchor);
                }
                for (int i = 0; i < arrDates.Length - 1; i++)
                {
                    li = new HtmlGenericControl("li");
                    u2.Controls.Add(li);
                    anchor = new HtmlGenericControl("a");
                    anchor.Attributes.Add("href","Add.aspx?date=" + arrDates[i] + "&name_or_date=d");
                    anchor.InnerText = arrDates[i];
                    li.Controls.Add(anchor);

                }
            }
            else if(cancelLesson.Text == "Activate")
            {
                string []arr=b.getContractsOfClient();
                string name = user_name_tbx.Text;
                string type = contract_type_tbx.Text;
                if(name==String.Empty || type==String.Empty)
                {
                    err.Text = "Please fill both fields";
                    err.Visible = true;
                    return;
                }
                if(!b.UserName_exist(name))
                {
                    err.Text = "This user does not in exist in records";
                    err.Visible = true;
                    return;
                }
                if (!b.contractType_exist(type))
                {
                    err.Text = "This contract type does not exist in records";
                    err.Visible = true;
                    return;
                }
                err.Text = b.updateUserContract(name,type);
                err.Visible = true;
                return;
            }
            else if (cancelLesson.Text == "Remove")
            {
                //string[] arr = b.getContractsOfClient();
                string id = user_name_tbx.Text;
                if (!b.Teacher_exist(id))
                {
                    err.Text = "This teacher does not in exist in JumpUp records";
                    err.Visible = true;
                    return;
                }
                err.Text = "Teacher has removed successfully from teachers list"/*b.updateUserContract(name)*/;
                err.Visible = true;
                return;
            }

        }

        protected void approveContract_Click(object sender, EventArgs e)
        {
            if(approveContract.Text== "Activate a Client Contract")
            {
                contract.Visible = true;
                c_userName.Visible = true;
                cancelLesson.Text = "Activate";
                approveContract.Text = "Back";
                updateData.Visible = false;
                removeTeacher.Visible = false;
            }
            else if(approveContract.Text == "Back")
            {
                Response.Redirect("Worker.aspx");
            }
            
        }

        protected void update_Click(object sender, EventArgs e)
        {

        }

        protected void removeTeacher_Click(object sender, EventArgs e)
        {
            if (removeTeacher.Text == "Remove a Teacher from Teachers List")
            {
                usr_name_lbl.Text = "Teacher id";
                c_userName.Visible = true;
                cancelLesson.Text = "Remove";
                approveContract.Text = "Back";
                updateData.Visible = false;
                removeTeacher.Visible = false;
            }
            else if (approveContract.Text == "Back")
            {
                Response.Redirect("Worker.aspx");
            }
        }

        protected void user_name_tbx_TextChanged(object sender, EventArgs e)
        {
            

        }
    }
}