﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JumpUp
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            dal d = new dal();
            string x=d.UserName_exists("fff");
            string y = x;
            Page.ClientScript.RegisterStartupScript(this.GetType(),"Scripts","<script>alert('!!!!!!!');</script>");
        }
    }
}