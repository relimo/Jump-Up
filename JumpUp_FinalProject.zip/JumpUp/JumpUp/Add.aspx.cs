﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using JumpUp;

namespace JumpUp
{
    public partial class Add : System.Web.UI.Page
    {
        Bl b = new Bl();
        string name_or_date;
        string date;
        string lesson;
        protected void Page_Load(object sender, EventArgs e)
        {

            if ((string)Session["userName"] == null)
                Response.Redirect("Home.aspx");

            lesson = Request.QueryString["name"];
            name_or_date = Request.QueryString["name_or_date"];
            date = Request.QueryString["date"];

            //client dispaly - add a new lesson
            if ((string)Session["role"] == "Client")
            {

                Label1.Visible = false;
                title.InnerText = "Add New Lesson";
                
                switch (name_or_date)
                {

                    case "n":
                        lbl_choose.InnerText = "Choose Date and Time and a room:";
                        if (!IsPostBack)
                        {
                            string[] arr = b.getDateAndTime_according_to_lesson(lesson);

                            for (int i = 0; i < arr.Length - 1; i++)
                            {

                                DropDownList1.Items.Add(arr[i]);

                            }
                        }
                        break;
                    case "d":
                        lbl_choose.InnerText = "Choose a lesson:";
                        if (!IsPostBack)
                        {
                            string[] arr2 = b.get_lesson_according_to_date(date);

                            for (int i = 0; i < arr2.Length - 1; i++)
                                DropDownList1.Items.Add(arr2[i]);
                        }
                        break;


                    default:
                        break;
                }
            }
            //worker dispaly - remove a lesson
            else if ((string)Session["role"] == "Worker")
            {
                title.InnerText = "Remove a Lesson";
                Label1.Visible = false;
                BtnAdd.Text = "Remove the lesson";
                btn_lto_leesons_page.Text = "Back";
                btn_to_general_lesson_list.Visible = false;

                switch (name_or_date)
                {

                    case "n":
                        lbl_choose.InnerText = "Choose Date and Time and a room:";
                        if (!IsPostBack)
                        {
                            string[] arr = b.getDateAndTime_according_to_lesson(lesson);

                            for (int i = 0; i < arr.Length - 1; i++)
                            {

                                DropDownList1.Items.Add(arr[i]);

                            }
                        }
                        break;
                    case "d":
                        lbl_choose.InnerText = "Choose a lesson:";
                        if (!IsPostBack)
                        {
                            string[] arr2 = b.get_lesson_according_to_date(date);

                            for (int i = 0; i < arr2.Length - 1; i++)
                                DropDownList1.Items.Add(arr2[i]);
                        }
                        break;


                    default:
                        break;
                }
            }
        }

        protected void BtnAdd_Click(object sender, EventArgs e)
        {

            if ((string)Session["role"] == "Client")
            {

                string selected = Request.Form[DropDownList1.UniqueID];

                // string selected = DropDownList1.SelectedValue;
                string a;
                if (selected.Contains("\n"))
                    a = selected.Substring(selected.Length - 3, 1);
                else
                    a = selected.Substring(selected.Length - 2, 1);
                int room = int.Parse(a);

                if (name_or_date.Equals("n"))
                {
                    date = selected.Substring(0, 16);
                }

                string res = b.addLesson((string)Session["userName"], date, room);
                if (res.Equals("error"))
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('You have already registered to this lesson / hour!');</script>");
                else Label1.Visible = true;
            }

            else if((string)Session["role"] == "Worker")
            {

                string selected = Request.Form[DropDownList1.UniqueID];

                // string selected = DropDownList1.SelectedValue;
                string less;
                if (selected.Contains("\n"))
                    less = selected.Substring(selected.Length - 3, 1);
                else
                    less = selected.Substring(selected.Length - 2, 1);
                int room = int.Parse(less);

                if (name_or_date.Equals("n"))
                {
                    date = selected.Substring(0, 16);
                }

                string res = b.removeLesson( date, room);
                if (res.Equals("error"))
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "Scripts", "<script>alert('Error occurred while deleting this lesson!');</script>");
                else
                {
                    BtnAdd.Visible = false;
                    Label1.Text = "Lesson has removed successfully";
                    Label1.Visible = true;
                }
            }

        }

        protected void btn_lto_leesons_page_Click(object sender, EventArgs e)
        {
            if((string)Session["role"] == "Client")
                Response.Redirect("individual.aspx");
            else if((string)Session["role"] == "Worker")
                Response.Redirect("Worker.aspx");
        }

        protected void btn_to_general_lesson_list_Click(object sender, EventArgs e)
        {
            Response.Redirect("individual.aspx");
        }
    }
}