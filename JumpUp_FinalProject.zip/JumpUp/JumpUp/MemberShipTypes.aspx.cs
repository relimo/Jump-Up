﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace JumpUp
{
    public partial class MemberShipTypes : System.Web.UI.Page
    {
        dal dal = new dal();
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void one_m_MemberShip(object sender, EventArgs e)
        {


        }
        protected void six_m_MemberShip(object sender, EventArgs e)
        {


        }
        protected void twelve_m_MemberShip(object sender, EventArgs e)
        {


        }
        protected void B_R_membership_Click(object sender, EventArgs e)
        {
            Response.Redirect("MemberShipTypes.aspx");

        }
        protected void on_register_yearly_Click(object sender, EventArgs e)
        {
            string user = (string)Session["userName"];
            congrads.Visible = true;
            payment.Visible = true;
            int contract_id = 10;
            dal.addClients_contract(user, contract_id);

        }
        protected void on_register_monthly_Click(object sender, EventArgs e)
        {
            string user = (string)Session["userName"];
            congrads.Visible = true;
            payment.Visible = true;
            int contract_id = 20;
            dal.addClients_contract(user, contract_id);
        }
        protected void on_register_multiple_Click(object sender, EventArgs e)
        {
            string user = (string)Session["userName"];
            congrads.Visible = true;
            payment.Visible = true;
            int contract_id = 30;
            dal.addClients_contract(user, contract_id);
        }
        protected void on_register_single_Click(object sender, EventArgs e)
        {
            string user = (string)Session["userName"];
            congrads.Visible = true;
            payment.Visible = true;
            int contract_id = 40;
            dal.addClients_contract(user, contract_id);
        }
        protected void home_p_Click(object sender, EventArgs e)
        {

            Response.Redirect("Home.aspx");
        }
        protected void individual_p_Click(object sender, EventArgs e)
        {
            Response.Redirect("individual.aspx");
        }


    }
}