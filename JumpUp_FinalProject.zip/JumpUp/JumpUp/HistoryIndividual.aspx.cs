﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JumpUp
{
    public partial class HistoryIndividual : System.Web.UI.Page
    {
        dal da = new dal();
        Bl helper = new Bl();

        protected void Page_Load(object sender, EventArgs e)
        {

            ///put the first name of the user in the label
            Label1.Text = da.get_client_name_according_to_user_name((string)Session["userName"]);

            if (!IsPostBack)
            {
                //1 means only future lessons 
                GridView1.DataSource = helper.getFutureOrPastDetailsForUser((string)Session["userName"], 0);
                GridView1.DataBind();
            }



        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //string autid = GridView1.DataKeys[e.RowIndex].Value.ToString();
            if (this.GridView1.Rows.Count > 0)
            {
                GridViewRow row = (GridViewRow)GridView1.Rows[e.RowIndex];


                string dt1 = GridView1.Rows[e.RowIndex].Cells[2].Text;
                int room = Convert.ToInt16(GridView1.Rows[e.RowIndex].Cells[3].Text);


                string user = (string)Session["userName"];
                da.delete_lesson(user, dt1, room);
                GridView1.DataSource = helper.getFutureOrPastDetailsForUser(user, 0);
                GridView1.DataBind();

            }




        }

        protected void addLesson_Click(object sender, EventArgs e)
        {
            string usr = (string)Session["username"];
            if (helper.userHasValidContract(usr))
                Response.Redirect("ChooseLesson.aspx");
            else
            {
                err.Text = "Sorry, You do not have a valid contract or it has been expired. Please renew or set a new Contract";
                err.Visible = true;
            }


        }
        protected void B_R_membership_Click(object sender, EventArgs e)
        {
            string user = (string)Session["userName"];
            Session.Add("userName", user);
            Response.Redirect("MemberShipTypes.aspx");

        }
    }
}