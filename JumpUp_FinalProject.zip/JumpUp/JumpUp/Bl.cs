﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JumpUp
{

    public class Bl
    {

        dal d = new dal();
        const int client = 0;
        const int worker = 1;
        const int nor = -1;

        public bool UserName_exist(string name)
        {
            string s1 = d.UserName_exists(name);
            if (s1 == "")
                return false;
            return true;
        }
        public bool Teacher_exist(string id)
        {
            string s = d.teacher_exists(id);
            if (s == "")
                return false;
            return true;
        }

        public string updateUserContract(string name, string type)
        {
            string s = d.getClientContractStatus(name,type);
            //user did not regist to a contract
            if (s == "")
                return "user has no registered contract of this type";
            if (s == "1")
                return "user contract is already approved";
            int i = d.approveClientContract(name);
            if (i == 0)
                return "Error in approving client contract";
            return "User contract has approved successfully";
        }

        public bool userHasValidContract(string user)
        {
            string s_date = d.getContractExpirationDate(user);
            if (s_date.Equals(String.Empty))
                return false;
            DateTime currentDate = DateTime.Now;
            int currentDay = currentDate.Day;
            int currentMonth = currentDate.Month;
            int currentYear = currentDate.Year;

            int i = s_date.IndexOf("/");
            string month = s_date.Substring(0, i);
            s_date = s_date.Substring(i + 1);
            i = s_date.IndexOf("/");
            string day = s_date.Substring(0, i);
            s_date = s_date.Substring(i + 1);
            i = s_date.IndexOf(" ");
            string year = s_date.Substring(0, i);

            int expirationDay = Int32.Parse(day);
            int expirationMonth = Int32.Parse(month);
            int expirationYear = Int32.Parse(year);

            if (currentYear > expirationYear)
                return false;
            if (currentYear < expirationYear)
                return true;
            //case currentYear=expirationYear
            if (currentMonth > expirationMonth)
                return false;
            if (currentMonth < expirationMonth)
                return true;
            //case currentMonth=expirationMonth
            if (currentDay > expirationDay)
                return false;

            return true;
        }

        public string[] getAllLessons()
        {
            string[] arr = new string[20];
            string result = d.getAllLessons();
            if (result.Equals("error"))
            {
                arr[0] = "error";
                return arr;

            }
            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);

            return arr;

        }
        public string[] getAllDates()
        {
            string[] arr = new string[20];
            string result = d.getAllDates();


            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);

            return arr;

        }

        public string[] getDateAndTime_according_to_lesson(string name)
        {

            string[] arr = new string[20];
            string result = d.getDateAndTime_according_to_lesson(name);
            if (result.Equals("error"))
            {
                arr[0] = "error";
                return arr;

            }
            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);

            return arr;

        }
        public string[] get_lesson_according_to_date(string date)
        {

            string[] arr = new string[20];
            string result = d.getLesson_name_according_to_date(date);

            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);

            return arr;
        }

        public bool contractType_exist(string type)
        {
            string s = d.contractType_exists(type);
            if (s == "")
                return false;
            return true;
        }

        public string[] getContractsOfClient()
        {
            string[] arr = new string[20];
            string result = d.getAllUserContracts();
            if (result.Equals("error"))
            {
                arr[0] = "error";
                return arr;

            }
            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);

            return arr;
        }

        public string addLesson(string u_name, string date, int room)
        {
            string res = d.addLesson(u_name, date, room);
            if (res.Equals("error"))
                return "error";
            return "true";
        }
        public string removeLesson(string date, int room)
        {
            string res = d.remove_lesson(date, room);
            if (res.Equals("error"))
                return "error";
            return "true";
        }
        public int checkPassword(string name, string password)
        {

            string s2 = d.UserName_andPasword_exist(name, password);

            if (s2 == "")
            {
                s2 = d.worker_UserName_andPasword_exist(name, password);
                if (s2 == "")
                    return nor;
                return worker;
            }
            return client;
        }

        public string addClient(string u_name, string pw, string f_name, string l_name, string email, string birthday)
        {
            if (d.UserName_exists(u_name).Equals("error"))
                return "error";
            if (d.UserName_exists(u_name) != "")//there is already the same user name
                return "false";

            d.addClients(u_name, pw, f_name, l_name, email, birthday);
            return "true";
        }
        public LinkedList<Lesson> getFutureOrPastDetailsForUser(string user, int futureOrPast)
        {
            DateTime currentDate = DateTime.Now;
            int currentDay = currentDate.Day;
            int currentMonth = currentDate.Month;
            int currentYear = currentDate.Year;



            int dayInList;
            int monthInList;
            int yearInList;




            LinkedList<Lesson> lessons = d.getDetailsForUser(user);
            LinkedList<Lesson> future = new LinkedList<Lesson>();
            LinkedList<Lesson> past = new LinkedList<Lesson>();
            String date, month, day, year;
            int i;
            foreach (var item in lessons)
            {
                date = item.Date_and_hour;

                i = date.IndexOf("/");
                month = date.Substring(0, i);
                date = date.Substring(i + 1);
                i = date.IndexOf("/");
                day = date.Substring(0, i);
                date = date.Substring(i + 1);
                i = date.IndexOf(" ");
                year = date.Substring(0, i);

                dayInList = Int32.Parse(day);
                monthInList = Int32.Parse(month);
                yearInList = Int32.Parse(year);

                if (currentYear > yearInList)
                    past.AddFirst(item);


                else if (currentYear < yearInList)
                    future.AddFirst(item);
                //case currentYear=expirationYear
                else if (currentMonth > monthInList)
                    past.AddFirst(item);
                else if (currentMonth < monthInList)
                    future.AddFirst(item);
                //case currentMonth=expirationMonth
                else if (currentDay > dayInList)
                    past.AddFirst(item);
                else future.AddFirst(item);

            }//foreach

            if (futureOrPast == 1)//1 means future
                return future;
            return past;
        }
    }
}