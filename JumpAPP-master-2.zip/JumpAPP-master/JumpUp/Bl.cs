﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace JumpUp
{

    public class Bl
    {

        dal d = new dal();

        public bool UserName_exist(string name, string password)
        {
            string s1 = d.UserName_exists(name);
            if (s1 == "")
                return false;
            return true;






        }

        public string[] getAllLessons()
        {
            string[] arr = new string[20];
            string result = d.getAllLessons();
            if (result.Equals("error"))
            {
                arr[0] = "error";
                return arr;

            }




            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);


            return arr;


        }
        public string[] getAllDates()
        {
            string[] arr = new string[20];
            string result = d.getAllDates();


            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);


            return arr;


        }


        public string[] getDateAndTime_according_to_lesson(string name)
        {

            string[] arr = new string[20];
            string result = d.getDateAndTime_according_to_lesson(name);
            if (result.Equals("error"))
            {
                arr[0] = "error";
                return arr;

            }




            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);


            return arr;



        }
        public string[] get_lesson_according_to_date(string date)
        {

            string[] arr = new string[20];
            string result = d.getLesson_name_according_to_date(date);

            char[] c = new char[1];
            c[0] = '\n';
            arr = result.Split(c);


            return arr;



        }

        public string addLesson(string u_name, string date, int room)
        {
            string res = d.addLesson(u_name, date, room);
            if (res.Equals("error"))
                return "error";



            return "true";


        }
        public bool checkPassword(string name, string password)
        {

            string s2 = d.UserName_andPasword_exist(name, password);
            if (s2 == "")
                return false;
            return true;
        }

        public string addClient(string u_name, string pw, string f_name, string l_name, string email, string birthday)
        {
            if (d.UserName_exists(u_name).Equals("error"))
                return "error";
            if (d.UserName_exists(u_name) != "")//there is already the same user name
                return "false";

            d.addClients(u_name, pw, f_name, l_name, email, birthday);
            return "true";
        }
    }
}